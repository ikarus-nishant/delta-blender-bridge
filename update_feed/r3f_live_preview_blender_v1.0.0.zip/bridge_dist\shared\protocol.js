"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_WS_PORT = exports.DEFAULT_HTTP_PORT = void 0;
exports.DEFAULT_HTTP_PORT = 48731;
exports.DEFAULT_WS_PORT = 48732;
