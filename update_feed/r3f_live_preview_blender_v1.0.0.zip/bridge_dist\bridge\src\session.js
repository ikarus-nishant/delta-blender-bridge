import path from "node:path";
import { assertInsideDirectory } from "./security.js";
export class SessionStore {
    sessions = new Map();
    create(sessionId, token, assetDir, environmentUrl, toneMapping) {
        const normalizedDir = path.resolve(assetDir);
        const record = {
            sessionId,
            token,
            assetDir: normalizedDir,
            createdAt: Date.now(),
            environmentUrl: environmentUrl ?? null,
            toneMapping,
        };
        this.sessions.set(sessionId, record);
        return record;
    }
    count() {
        return this.sessions.size;
    }
    get(sessionId) {
        return this.sessions.get(sessionId);
    }
    validate(sessionId, token) {
        const session = this.sessions.get(sessionId);
        if (!session || session.token !== token) {
            throw new Error("Invalid session token");
        }
        return session;
    }
    assetPathFor(sessionId, relativePath) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            throw new Error("Unknown session");
        }
        const target = path.join(session.assetDir, relativePath);
        return assertInsideDirectory(session.assetDir, target);
    }
    updateModel(sessionId, lastModelUrl, lastVersion, environmentUrl, toneMapping) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            throw new Error("Unknown session");
        }
        session.lastModelUrl = lastModelUrl;
        session.lastVersion = lastVersion;
        if (environmentUrl !== undefined) {
            session.environmentUrl = environmentUrl;
        }
        if (toneMapping) {
            session.toneMapping = toneMapping;
        }
        return session;
    }
    updateCamera(sessionId, camera) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            throw new Error("Unknown session");
        }
        session.camera = camera;
        return session;
    }
}
